import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:z_cabs/AllScreens/registrationScreen.dart';
import 'package:z_cabs/AllWidgets/progressDialog.dart';

import '../main.dart';
import 'mainScreen.dart';
// ignore: must_be_immutable
class LoginScreen extends StatelessWidget {

  TextEditingController emailTextEditingController = TextEditingController();

  //TextEditingController phoneTextEditingController=TextEditingController();
  TextEditingController passwordTextEditingController = TextEditingController();
  static const String idScreen = "login";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              SizedBox(height: 35.0,),
              Image(image: AssetImage("images/logo.png"),
                width: 390.0, height: 350.0,
                alignment: Alignment.center,
              ),
              SizedBox(height: 1.0,),
              Text("Login As A Rider",
                style: TextStyle(fontSize: 24.0, fontFamily: "Brand Bold"),),
              Padding(padding: EdgeInsets.all(20),
                child: Column(
                  children: [
                    SizedBox(height: 1.0,),
                    TextField(
                      controller: emailTextEditingController,
                      keyboardType: TextInputType.emailAddress,
                      decoration: InputDecoration(labelText: "Email",
                        labelStyle: TextStyle(fontSize: 18.0,),
                      ),
                      style: TextStyle(fontSize: 14.0),
                    ),
                    SizedBox(height: 1.0,),
                    TextField(
                      controller: passwordTextEditingController,
                      obscureText: true,
                      decoration: InputDecoration(labelText: "Password",
                        labelStyle: TextStyle(fontSize: 18.0,),
                      ),
                      style: TextStyle(fontSize: 14.0),
                    ),
                    SizedBox(height: 40.0,),
                    ElevatedButton(
                      child: Container(
                        height: 50.0,
                        child: Center(
                            child: Text("Login ", style: TextStyle(
                                fontSize: 18.0, fontFamily: "Brand Bold"),)
                        ),
                      ),
                      onPressed: () {
                        print("Clicked");
                        if (!emailTextEditingController.text.contains("@")) {
                          displayToastMessage(
                            "Email Address is not valid", context);
                        }
                        else if (passwordTextEditingController.text.isEmpty) {
                          displayToastMessage("Password is mandatory", context);
                        }
                        else {
                          LoginAndAuthenticateUser(context);
                        }
                      },
                    ),
                    SizedBox(height: 10.0,),
                    TextButton(onPressed: () {
                      Navigator.pushNamedAndRemoveUntil(
                          context, RegistrationScreen.idScreen, (
                          route) => false);
                    },
                      child: Text("Do not have an account? Register here  !"),)

                  ],
                ),
              ),


            ],
          ),
        ),
      ),
    );
  }

  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;

  // ignore: non_constant_identifier_names
  void LoginAndAuthenticateUser(BuildContext context) async {
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context)
        {
          return ProgressDialog(message: "Authenticating, Please wait . . . . . ",);
        }
    );
    final User firebaseUser = (await _firebaseAuth
        .signInWithEmailAndPassword(
        email: emailTextEditingController.text,
        password: passwordTextEditingController.text).catchError((errMsg) {
      Navigator.pop(context);
     displayToastMessage("Error: " + errMsg.toString(), context);
    })).user;

    if (firebaseUser != null) {
      //save info
      usersRef.child(firebaseUser.uid).once().then((DataSnapshot snap) {
        if (snap.value != null) {
          Navigator.pushNamedAndRemoveUntil(
              context, MainScreen.idScreen, (route) => false);
          displayToastMessage("You are Logged-in now", context);
        }
        else {
          Navigator.pop(context);
          _firebaseAuth.signOut();
          displayToastMessage(
              "No record exists for this user please create a new account",
              context);
        }
      }
      );
    }
    else {
      //error
      Navigator.pop(context);
      displayToastMessage("Error Occurred, Cannot signed-in", context);
    }

  }
}