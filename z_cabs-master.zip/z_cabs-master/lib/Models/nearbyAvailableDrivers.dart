class NearbyAvailableDrivers
{
  String key;
  double latitude, longitude;
  NearbyAvailableDrivers({this.key,this.latitude, this.longitude});

}