class Address {
  String placeFormattedAddress, placeName, placeId;
  double latitude;
  double longitude;
  Address(
      {this.placeFormattedAddress,
      this.placeName,
      this.placeId,
      this.latitude,
      this.longitude});
}
