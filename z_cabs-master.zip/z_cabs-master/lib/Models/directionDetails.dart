class DirectionDetails
{
  int distanceValue, durationValue;
  String distanceText, durationText, encodedPoints;

  DirectionDetails({this.distanceValue,this.durationValue,this.distanceText,this.durationText,this.encodedPoints,});
}