import 'package:firebase_auth/firebase_auth.dart';

import 'Models/allUsers.dart';

String mapKey="AIzaSyAphBnEt_0J3HQAD3S8vxZiqQ5nPBgwv0w";

User firebaseUser;
Users userCurrentInfo;
int driverRequestTimeOut = 40;
String statusRide = "";
String rideStatus = "Driver is Coming";
String carDetailsDriver = "";
String driverName = "";
String driverPhone = "";
String serverToken = "key=AAAAYT94gIw:APA91bGdIrKbdEqYtsn12KrBGxTWTt6wurlYiyZqfdlbAvfiPtYefFrvl2QHxg5xCOsm--q4jpe0d5pVcCyuyiBXo_fG3zq4dRpzyFp6lBQg4YrQSLm_4-c4ZWOX9XbJQr4yeUeHp6qZ";
