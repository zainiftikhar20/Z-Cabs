package com.example.z_cabs

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
